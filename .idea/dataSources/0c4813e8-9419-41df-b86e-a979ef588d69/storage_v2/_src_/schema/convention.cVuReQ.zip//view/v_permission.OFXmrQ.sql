create view v_permission as
  select distinct
    `a`.`id`              AS `userId`,
    `a`.`username`        AS `username`,
    `a`.`username`        AS `nickname`,
    `a`.`appid`           AS `appid`,
    `c`.`id`              AS `roleId`,
    `c`.`role_name`       AS `roleName`,
    `e`.`menu_code`       AS `menuCode`,
    `e`.`permission_code` AS `permissionCode`
  from ((((`convention`.`t_admin_user` `a` left join `convention`.`t_admin_user_role` `b`
      on ((`a`.`id` = `b`.`user_id`))) left join `convention`.`t_admin_role` `c`
      on ((`c`.`id` = `b`.`role_id`))) left join `convention`.`t_admin_role_permission` `d`
      on ((`d`.`role_id` = `b`.`role_id`))) left join `convention`.`t_admin_permission` `e`
      on ((`e`.`id` = `d`.`permission_id`)))
  where ((`a`.`deleted` = 0) and (`d`.`delete_status` = 1));

